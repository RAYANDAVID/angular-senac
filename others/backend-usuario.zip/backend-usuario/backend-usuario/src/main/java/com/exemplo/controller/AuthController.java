package com.exemplo.controller;

import com.exemplo.model.Usuario;
import com.exemplo.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import com.fasterxml.jackson.databind.ObjectMapper; 
import com.fasterxml.jackson.databind.node.ObjectNode;

class LoginRequest {
    public String username;
    public String password;
}


class LoginResponse {
    public String message;
    public String username;
    
    public LoginResponse(String message, String username) {
        this.message = message;
        this.username = username;
    }
}

class RegisterResponse {
    public String message;

    public RegisterResponse(String message) {
        this.message = message;
    }
}

@RestController
@RequestMapping("/api/auth") 
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private ObjectMapper objectMapper;

    @PostMapping("/login") 
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
       
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.username, loginRequest.password)
            );
            SecurityContextHolder.getContext().setAuthentication(authentication);
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            return ResponseEntity.ok(new LoginResponse("Login bem-sucedido!", userDetails.getUsername()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new RegisterResponse("Falha na autenticação: " + e.getMessage()));
        }
    }

    @PostMapping("/register") 
    public ResponseEntity<?> registerUser(@RequestBody Usuario signUpRequest) {
       
        if (usuarioService.findAllUsuarios().stream().anyMatch(u -> u.getUsername().equals(signUpRequest.getUsername()))) {
            ObjectNode errorResponse = objectMapper.createObjectNode();
            errorResponse.put("message", "Erro: Nome de usuário já está em uso!");
            return ResponseEntity.badRequest().body(errorResponse);
        }
       
        usuarioService.saveUsuario(signUpRequest); 
        return ResponseEntity.ok(new RegisterResponse("Usuário registrado com sucesso!"));
    }
}
