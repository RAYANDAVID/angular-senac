package com.exemplo.service;

import com.exemplo.model.Usuario;
import java.util.List;
import java.util.Optional;

public interface UsuarioService {
    List<Usuario> findAllUsuarios();
    Optional<Usuario> findUsuarioById(Long id);
    Usuario saveUsuario(Usuario usuario);
    Optional<Usuario> updateUsuario(Long id, Usuario usuarioDetails);
    void deleteUsuarioById(Long id);
}
